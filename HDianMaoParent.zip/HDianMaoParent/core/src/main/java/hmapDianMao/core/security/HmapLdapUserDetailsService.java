package hmapDianMao.core.security;

import com.hand.hap.account.dto.User;
import com.hand.hap.account.service.IUserService;
import com.hand.hap.core.IRequest;
import com.hand.hap.core.impl.RequestHelper;
import com.hand.hap.security.PasswordManager;
import hmap.core.hms.contact.domain.HmsCorpInfo;
import hmap.core.hms.contact.service.IHmsCorpInfoService;
import hmap.core.hms.system.domain.HmsUser;
import hmap.core.hms.system.mapper.SysUserMapper;
import hmap.core.hms.system.service.IHmsUserService;
import hmapDianMao.core.login.service.ILoginService;
import hmap.core.security.login.IClientDetailService;
import hmap.core.security.HmsMobileUserDetails;
import hmap.core.security.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.transaction.compensating.manager.TransactionAwareContextSourceProxy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hailor on 16/6/12.
 */
class HmapLdapUserDetailsService implements IClientDetailService {

    Logger logger = LoggerFactory.getLogger(HmapLdapUserDetailsService.class);

    @Autowired
    PasswordManager passwordManager;
    @Autowired
    private SysUserMapper sysUserMapper;
    @Autowired
    LdapManager ldapManager;
    @Autowired
    private IUserService userService;
    @Autowired
    private IHmsUserService iHmsUserService;
    @Autowired
    private IHmsCorpInfoService iHmsCorpInfoService;
    @Autowired
    private ILoginService iLoginService;
    @Value("${default.organizationId}")
    private String defaultOrganizationId;

    //UserNamePassword
    @Override
    public UserDetails loadUserByUsername(String username, String password) throws UsernameNotFoundException {

        IRequest iRequest = RequestHelper.getCurrentRequest();
        //需根据角色拿到orgId
        String selectOrganizationId = "";
        if(SecurityUtils.isCurrentUserInRole("ROLE_ADMIN")){
            HmsCorpInfo orgIdHmsCorpInfo = new HmsCorpInfo();
            orgIdHmsCorpInfo.setAdminUserName(username);
            orgIdHmsCorpInfo = iHmsCorpInfoService.selectByPrimaryKey(iRequest,orgIdHmsCorpInfo);
            if(orgIdHmsCorpInfo != null){
                selectOrganizationId = orgIdHmsCorpInfo.getId();
            }
        }else{
            selectOrganizationId = defaultOrganizationId;
        }

//        User tmpUser = userService.selectByUserName(username);
        HmsUser selectHmsUser = new HmsUser();
        selectHmsUser.setUserName(username);
        selectHmsUser.setOrganizationId(selectOrganizationId);
        List<HmsUser> tmpUserList = iHmsUserService.select(iRequest,selectHmsUser,1,10);
        if (tmpUserList.size() != 1) {
            throw new UsernameNotFoundException("User not found:" + username);
        }
        username = tmpUserList.get(0).getUserName();
        HmsUser hu = new HmsUser();
        hu.setUserName(username);
        List<HmsUser> userList = this.iHmsUserService.select(iRequest,hu,1,1);
        if(userList==null||userList.size()==0){
            throw new UsernameNotFoundException("User not found:" + username);
        }
        HmsUser user = userList.get(0);
        if(user.getOrganizationId()==null){
            throw new UsernameNotFoundException("User not found:" + username);
        }else{
            HmsCorpInfo hmsCorpInfo = new HmsCorpInfo();
            hmsCorpInfo.setId(user.getOrganizationId());
            hmsCorpInfo = iHmsCorpInfoService.selectByPrimaryKey(iRequest,hmsCorpInfo);
            if("handAdmin".equals(hmsCorpInfo.getAdminUserName())){
                iLoginService.handAdminLoginFunction(username,password,user.getOrganizationId());
            }
            if("Y".equals(user.getStatus()) && (user.getEndActiveDate() == null || user.getEndActiveDate().getTime() >= System.currentTimeMillis())) {
                List authorities = SecurityUtils.getAuthorities();
                String organizationId;
                String appId;
                List organizationIds;
                if(SecurityUtils.isCurrentUserInRole("ROLE_ADMIN")) {
                    throw new UsernameNotFoundException("User not found:" + username);
                } else {
                    //String organizationId= SecurityUtils.getCurrentUserOrganizationId();
                    organizationIds = this.sysUserMapper.selectOrganizationIdsByUserName(username);
                    organizationId = null;
                    appId = null;
                    if(organizationIds != null && organizationIds.size() != 0) {
                        organizationId = (String)organizationIds.get(0);
                        if(organizationId != null) {
                            appId = this.sysUserMapper.selectAppIdByOrganizationId(organizationId);
                        }
                    }else{
                        throw new UsernameNotFoundException("User not found:" + username);
                    }
                    if(hmsCorpInfo.getLoginType()==null||!hmsCorpInfo.getLoginType().toLowerCase().equals("ldap")){
                        throw new UsernameNotFoundException("User not found:" + username);
                    }
                    String userId = this.sysUserMapper.getMobileUserId(username, organizationId);
                    if(userId==null){
                        throw new UsernameNotFoundException("User not found:" + username);
                    }
                    authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                    this.sysUserMapper.activatedUser(username);
                    HmsMobileUserDetails userDetails = null;
                    LdapTemplate ldapTemplate = null;
                    try{
                        ldapTemplate = ldapManager.getLdapTemplate(hmsCorpInfo.getLdapBeanName());
                    }catch (Exception e){
                        userDetails = new HmsMobileUserDetails(userId,userId , user.getPasswordEncrypted(),
                                false, true, true, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                        return userDetails;
                    }
                    if(ldapTemplate==null){
                        userDetails = new HmsMobileUserDetails(userId,userId, user.getPasswordEncrypted(),
                                false, true, true, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                        return userDetails;
                    }
                    String serverAddress = ((LdapContextSource) ((TransactionAwareContextSourceProxy) ldapTemplate.
                            getContextSource()).getTarget()).getUrls()[0];
                    String baseDn = ((LdapContextSource)((TransactionAwareContextSourceProxy)ldapTemplate.getContextSource()).
                            getTarget()).getBaseLdapPathAsString();
                    String adminUserName = ((LdapContextSource)((TransactionAwareContextSourceProxy)ldapTemplate.getContextSource()).
                            getTarget()).getUserDn();
                    String adminPassword = ((LdapContextSource)((TransactionAwareContextSourceProxy)ldapTemplate.getContextSource()).
                            getTarget()).getPassword();
                    String ldapAttributeName = "employeeNumber";//暂时写死，需要改为配置后需要重写org.springframework.ldap.core.support.LdapContextSource,增加配置项
                    int result = LdapUserAuthenticateUtil.authenticate(adminUserName,adminPassword,username,password,serverAddress,baseDn,ldapAttributeName);
                    if(result==0){//返回认证结果 0 ldap连接失败 1 用户不存在 2 密码错误 3校验成功
                        userDetails = new HmsMobileUserDetails(userId,userId , user.getPasswordEncrypted(),
                                false, true, true, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                    }
                    else if(result==1){//返回认证结果 0 ldap连接失败 1 用户不存在 2 密码错误 3校验成功
                        userDetails = new HmsMobileUserDetails(userId,userId , user.getPasswordEncrypted(),
                                true, false, true, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                    }
                    else if(result==2){//返回认证结果 0 ldap连接失败 1 用户不存在 2 密码错误 3校验成功
                        userDetails = new HmsMobileUserDetails(userId,userId, user.getPasswordEncrypted(),
                                true, true, false, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                    }
                    else if(result==3){//返回认证结果 0 ldap连接失败 1 用户不存在 2 密码错误 3校验成功
                        userDetails = new HmsMobileUserDetails(userId,userId , user.getPasswordEncrypted(),
                                true, true, true, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                    }
                    else{
                        userDetails = new HmsMobileUserDetails(userId,userId, user.getPasswordEncrypted(),
                                false, true, true, true, authorities, organizationId, appId, organizationIds,user.getUserName());
                    }
                    return userDetails;
                }
            } else {
                throw new UsernameNotFoundException("User not found:" + username);
            }
        }
    }

}
