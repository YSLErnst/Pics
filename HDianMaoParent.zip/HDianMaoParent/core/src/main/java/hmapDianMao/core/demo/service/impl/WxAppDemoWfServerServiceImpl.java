package hmapDianMao.core.demo.service.impl;

import com.hand.hap.system.dto.ResponseData;
import hmap.core.hms.contact.domain.HmsStaff;
import hmap.core.hms.contact.service.IHmsStaffService;
import hmap.core.hms.messageManager.dto.HmsUserMessagePushDto;
import hmap.core.hms.messageManager.service.IHmsUserMessagePushService;
import hmap.core.hms.messageTemplate.service.IHmsMessageTemplateService;
import hmap.core.hms.system.service.ILogService;
import hmap.core.security.SecurityUtils;
import hmapWorkflow.core.workflow.service.IWfServerService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.UnsupportedEncodingException;

/**
 * Created by lp on 2017/3/27.
 */
public class WxAppDemoWfServerServiceImpl implements IWfServerService {

    @Autowired
    private IHmsStaffService iHmsStaffService;

    @Autowired
    private IHmsMessageTemplateService iHmsMessageTemplateService;

    @Autowired
    private IHmsUserMessagePushService iHmsUserMessagePushService;

    @Autowired
    private ILogService iLogService;

    @Override
    public String getUserAvatar(String accountNumber) {
        String organizationId= SecurityUtils.getCurrentUserOrganizationId();
        HmsStaff staff = iHmsStaffService.selectByAccountNumber(accountNumber,organizationId);
        if(staff==null){
            return "";
        }
        return staff.getAvatar();
    }

    @Override
    public ResponseData validateParams(JSONObject params){
        ResponseData responseData = new ResponseData();
        responseData.setCode("0");
        responseData.setMessage("数据校验通过");
        if(!params.has("workflow")){
            responseData.setCode("100");
            responseData.setMessage("收到的JSON不包含workflow对象");
            return responseData;
        }
        JSONObject workflow = params.getJSONObject("workflow");
        if(!workflow.has("template_code")){
            responseData.setCode("101");
            responseData.setMessage("template_code字段不能为空");
            return responseData;
        }else{
            int len = this.getStringBytesLength(workflow.getString("template_code"));
            if(len > 200){
                responseData.setCode("102");
                responseData.setMessage("template_code字段长度不能超过200个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("102");
                responseData.setMessage("template_code字段长度获取失败");
                return responseData;
            }
        }
        if(!workflow.has("source_instance_id")){
            responseData.setCode("103");
            responseData.setMessage("source_instance_id字段不能为空");
            return responseData;
        }else{
            int len = this.getStringBytesLength(workflow.getString("source_instance_id"));
            if(len > 200){
                responseData.setCode("104");
                responseData.setMessage("source_instance_id字段长度不能超过200个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("104");
                responseData.setMessage("source_instance_id字段长度获取失败");
                return responseData;
            }
        }
        if(!workflow.has("title")){
            responseData.setCode("105");
            responseData.setMessage("title字段不能为空");
            return responseData;
        }else{
            int len = this.getStringBytesLength(workflow.getString("title"));
            if(len > 128){
                responseData.setCode("106");
                responseData.setMessage("title字段长度不能超过128个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("106");
                responseData.setMessage("title字段长度获取失败");
                return responseData;
            }
        }
        if(!workflow.has("approver_code")){
            responseData.setCode("107");
            responseData.setMessage("approver_code字段不能为空");
            return responseData;
        }else{
            int len = this.getStringBytesLength(workflow.getString("approver_code"));
            if(len > 200){
                responseData.setCode("108");
                responseData.setMessage("approver_code字段长度不能超过200个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("108");
                responseData.setMessage("approver_code字段长度获取失败");
                return responseData;
            }
        }
        if(!workflow.has("create_user_code")){
            responseData.setCode("109");
            responseData.setMessage("create_user_code字段不能为空");
            return responseData;
        }else{
            int len = this.getStringBytesLength(workflow.getString("create_user_code"));
            if(len > 200){
                responseData.setCode("110");
                responseData.setMessage("create_user_code字段长度不能超过200个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("110");
                responseData.setMessage("create_user_code字段长度获取失败");
                return responseData;
            }
        }
        //非必须字段的长度限制
        if(workflow.has("source_node_id")){
            int len = this.getStringBytesLength(workflow.getString("source_node_id"));
            if(len > 200){
                responseData.setCode("111");
                responseData.setMessage("source_node_id字段长度不能超过200个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("111");
                responseData.setMessage("source_node_id字段长度获取失败");
                return responseData;
            }
        }
        if(workflow.has("source_record_id")){
            int len = this.getStringBytesLength(workflow.getString("source_record_id"));
            if(len > 200){
                responseData.setCode("112");
                responseData.setMessage("source_record_id字段长度不能超过200个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("112");
                responseData.setMessage("source_record_id字段长度获取失败");
                return responseData;
            }
        }
        if(workflow.has("description")){
            int len = this.getStringBytesLength(workflow.getString("description"));
            if(len > 512){
                responseData.setCode("113");
                responseData.setMessage("description字段长度不能超过512个字节,当前"+len+"字节");
                return responseData;
            }
            if(len==-1){
                responseData.setCode("113");
                responseData.setMessage("description字段长度获取失败");
                return responseData;
            }
        }
        return responseData;
    }

    @Override
    public ResponseData pushNewsMessage(JSONObject workflow) {
        ResponseData responseData = new ResponseData();
        responseData.setCode("0");
        responseData.setMessage("推送消息成功");
        JSONObject params = new JSONObject();

        params.put("title",workflow.getString("title"));
        params.put("description",workflow.getString("description"));

        HmsUserMessagePushDto hmsUserMessagePushDto = iHmsMessageTemplateService.selectByMessageTypeCodeAndMessageParam("workflow",params,workflow);//没有参数
        hmsUserMessagePushDto.setUserId(workflow.getString("approver_code"));
        hmsUserMessagePushDto.setTemplateTypeCode("workflow");
        hmsUserMessagePushDto = iHmsUserMessagePushService.pushMessage(hmsUserMessagePushDto);
        iLogService.jobLogInfo("/sendMessageTakePillLongJob message:"+JSONObject.fromObject(hmsUserMessagePushDto).toString());
        return responseData;
    }

    private int getStringBytesLength(String str){
        try {
            return str.getBytes("UTF-8").length;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return -1;
        }
    }
}
