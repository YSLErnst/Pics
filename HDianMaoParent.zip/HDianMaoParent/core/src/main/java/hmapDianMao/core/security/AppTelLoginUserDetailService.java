package hmapDianMao.core.security;
import com.hand.hap.core.IRequest;
import com.hand.hap.core.impl.RequestHelper;
import hmap.core.hms.contact.domain.HmsStaff;
import hmap.core.hms.contact.service.IHmsStaffService;
import hmap.core.hms.system.domain.HmsAccount;
import hmap.core.hms.system.mapper.SysUserMapper;
import hmap.core.hms.system.service.IHmsAccountService;
import hmap.core.security.HmsAppUserDetails;
import hmap.core.security.SecurityUtils;
import hmap.core.security.login.IClientDetailService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Koma Tshu on 2017/11/7.
 */
public class AppTelLoginUserDetailService implements IClientDetailService {
    @Autowired
    private IHmsStaffService iHmsStaffService;
    @Autowired
    private SysUserMapper sysUserMapper;
    @Autowired
    IHmsAccountService iHmsAccountService;

    @Override
    public UserDetails loadUserByUsername(String mobile, String password) throws UsernameNotFoundException {
        IRequest iRequest = RequestHelper.getCurrentRequest();
        HmsStaff selectHmsStaff = new HmsStaff();
        if(mobile != null && mobile.startsWith("+86")){
            mobile = mobile.substring(3,mobile.length());
        }
        selectHmsStaff.setMobile(mobile);
        List<HmsStaff> staffList = iHmsStaffService.select(iRequest,selectHmsStaff,1,1);

        //手机号不能为空
        if(StringUtils.isBlank(mobile)){
            throw new UsernameNotFoundException("手机号不能为空");
        }

        //校验是否已注册
        HmsAccount hmsAccount = null;
        if (staffList.size() == 1) {
            HmsAccount selectAccount = new HmsAccount();
            selectAccount.setPhone(staffList.get(0).getMobile());
            List<HmsAccount> selectAccountList = iHmsAccountService.select(iRequest, selectAccount, 1, 1);
            if (selectAccountList.size() == 1) {
                hmsAccount = selectAccountList.get(0);
            }
        }
        if (hmsAccount != null && "N".equals(hmsAccount.getHaveRegister())) {
            throw new UsernameNotFoundException("10003");
        }

        //校验是否匹配租户通讯录（手机号是否存在）
        if (staffList.size() == 0 || staffList.get(0).getOrganizationId() == null) {
            throw new UsernameNotFoundException("10001");
        }

        if (hmsAccount == null) {
            throw new UsernameNotFoundException("10001");
        }
        if (hmsAccount.getMasterOrganizationId() == null) {
            throw new UsernameNotFoundException("10001");
        } else if ("Y".equals(hmsAccount.getStatus()) && (hmsAccount.getEndActiveDate() == null || hmsAccount.getEndActiveDate().getTime() >= System.currentTimeMillis())) {
            List authorities = SecurityUtils.getAuthorities();
            String organizationId = null;
            String appId;
//            List organizationIds;
            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
            this.iHmsAccountService.activatedAccount("phone",staffList.get(0).getMobile());
            organizationId = hmsAccount.getMasterOrganizationId();
            appId = this.sysUserMapper.selectAppIdByOrganizationId(organizationId);;
            new ArrayList();
//            organizationIds = this.iHmsAccountService.selectOrganizationIdsByPhoneAndThirdPartyId(hmsAccount.getPhone(),hmsAccount.getThirdPartyId());

            String userId = hmsAccount.getUserId();
            HmsAppUserDetails userDetails = new HmsAppUserDetails(userId, userId, hmsAccount.getPasswordEncrypted(), true, true, true, true, authorities, organizationId, appId, hmsAccount.getPhone(),null,null);
            return userDetails;
        } else {
            throw new UsernameNotFoundException("10001");
        }
    }
}
