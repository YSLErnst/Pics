package hmapDianMao.core.demo.service.impl;

import com.hand.hap.account.dto.User;
import com.hand.hap.account.service.IUserService;
import com.hand.hap.security.CustomUserDetails;
import hmap.core.hms.api.util.Sign;
import hmap.core.hms.system.service.ILoginAttemptService;
import hmap.core.security.login.IClientDetailService;
import hmap.core.util.StatelessRequestHelper;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.authentication.dao.SaltSource;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.authentication.encoding.PlaintextPasswordEncoder;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by enlline on 4/14/17.
 */
public class ApiTestAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {
    private IClientDetailService userDetailsService;
    @Autowired
    private IUserService userService;
    @Resource(name = "restTemplate")
    private RestTemplate restTemplate;
    @Override
    protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
            CustomUserDetails userDetails = null;
            try {
                String url ="http://localhost:8082/hmap/api/public/userNameValidate";
                HttpHeaders httpHeaders = new HttpHeaders();
                HttpEntity httpEntity = new HttpEntity(httpHeaders);
                SortedMap<Object,Object> parameters = new TreeMap<Object,Object>();
                parameters.put("code",(String)authentication.getCredentials());
                parameters.put("timeStamp",new Date().getTime());
                parameters.put("nonce", UUID.randomUUID().toString());
                parameters.put("userName",username);
                parameters.put("systemIdentifier","fd314a88-eb4b-4675-b611-489dfd25c5ae");
                String signature = Sign.getSign(parameters, "token");
                parameters.put("signature",signature);
                Set es = parameters.entrySet();
                Iterator iterator = es.iterator();
                url += "?";
                while (iterator.hasNext()) {
                    Map.Entry entry = (Map.Entry)iterator.next();
                    String k = (String)entry.getKey();
                    String v = entry.getValue().toString();
                    if(null != v && !"".equals(v)){
                    url += k + "=" + v + "&";
                    }
                }

               String responseData = restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class).getBody();
                JSONObject responeJson = JSONObject.fromObject(responseData);
                if(responeJson.getBoolean("success")){
                User user = this.userService.selectByUserName(username,null);
                ArrayList authorities = new ArrayList();
                authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                userDetails = new CustomUserDetails(user.getUserId(), user.getUserName(),
                        user.getPasswordEncrypted(), true, true, true, true, authorities);
                }else{
                    throw new AuthenticationServiceException("校验错误");
                }
            } catch (UsernameNotFoundException var5) {
                throw var5;
            } catch (Exception var6) {
                throw new AuthenticationServiceException(var6.getMessage(), var6);
            }

            if(userDetails == null) {
                throw new AuthenticationServiceException("UserDetailsService returned null, which is an interface contract violation");
            } else {
                return userDetails;
            }
    }

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {

    }

    public IClientDetailService getUserDetailsService() {
        return userDetailsService;
    }

    public void setUserDetailsService(IClientDetailService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }
}
