package hmapDianMao.core.security;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * Created by Koma Tshu on 2017/12/25.
 */
public interface IClientWebDetailService {
    UserDetails loadUserByUsername(String username, String password, String authType) throws UsernameNotFoundException;
}
