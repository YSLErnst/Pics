package hmapDianMao.core.login.service.impl;

import hmap.core.hms.api.dto.HeaderAndLineDTO;
import hmap.core.hms.api.service.IHmsHeaderService;
import hmap.core.hms.system.service.ILogService;
import hmapDianMao.core.login.service.ILoginService;
import net.sf.json.JSONObject;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;

/**
 * Created by enlline on 9/10/17.
 */
@Service
public class LoginServiceImpl implements ILoginService {
    @Autowired
    IHmsHeaderService headerService;
    @Autowired
    ILogService iLogService;
    @Autowired
    HttpClientBuilder httpClientBuilder;
    @Override
    public void handAdminLoginFunction(String userName, String password,String organizationId) {
        try {
            HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
                    = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());
            clientHttpRequestFactory.setConnectTimeout(5000);
            clientHttpRequestFactory.setReadTimeout(5000);
            RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
            HeaderAndLineDTO headerAndLineDTO = this.headerService.getHeaderAndLine("HandMobile", "crmLogin", organizationId);
            String url = headerAndLineDTO.getDomainUrl() + headerAndLineDTO.getIftUrl()+"?userName="+userName+"&password="+password;
            HttpHeaders httpHeaders = new HttpHeaders();
            HttpEntity httpEntity = new HttpEntity(httpHeaders);
            String resultData = (String)restTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class, new Object[0]).getBody();
            iLogService.serviceLogInfo("crm login:userName="+userName+",password="+password+",result="+resultData);
        }catch (Exception e){
            iLogService.serviceLogError("crm login:",e);
        }
    }
}
