package hmapDianMao.core.security;
import com.hand.hap.core.IRequest;
import com.hand.hap.core.impl.RequestHelper;
import hmap.core.hms.audit.event.AdminLoginAuditLogPersistentEvent;
import hmap.core.hms.contact.domain.HmsStaff;
import hmap.core.hms.contact.service.IHmsCorpInfoService;
import hmap.core.hms.contact.service.IHmsStaffService;
import hmap.core.hms.system.domain.HmsAccount;
import hmap.core.hms.system.mapper.SysUserMapper;
import hmap.core.hms.system.service.IHmsAccountService;
import hmap.core.hms.system.service.IHmsUserService;
import hmap.core.security.HmsWebUserDetails;
import hmap.core.security.SecurityUtils;
import hmap.core.util.StatelessRequestHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Koma Tshu on 2017/11/14.
 */
public class WebLoginUserDetailService implements IClientWebDetailService {
    Logger logger = LoggerFactory.getLogger(WebLoginUserDetailService.class);

    @Autowired
    private SysUserMapper sysUserMapper;
    @Autowired
    private IHmsCorpInfoService iHmsCorpInfoService;
    @Autowired
    private IHmsUserService iHmsUserService;
    @Autowired
    private IHmsStaffService iHmsStaffService;
    @Value("${default.organizationId}")
    private String defaultOrganizationId;
    @Autowired
    private IHmsAccountService iHmsAccountService;

    //UserNamePassword
    @Override
    public UserDetails loadUserByUsername(String mobileUsername, String password, String authType) throws UsernameNotFoundException {
        IRequest iRequest = RequestHelper.getCurrentRequest();
        HmsWebUserDetails webUserDetails = null;
        if ("WEBNUM".equals(authType)) {
            HmsAccount selectHmsAccount = new HmsAccount();
            selectHmsAccount.setAdminUserName(mobileUsername);
            List<HmsAccount> accountList = iHmsAccountService.select(iRequest, selectHmsAccount, 1, 1);
            if (accountList.size() != 1) {
                throw new UsernameNotFoundException("10001");
            }
            HmsAccount resultHmsAccount = accountList.get(0);
            //账号已经失效 或 账号过期
            if (!"Y".equals(resultHmsAccount.getStatus()) || (resultHmsAccount.getEndActiveDate() != null && resultHmsAccount.getEndActiveDate().getTime() < System.currentTimeMillis())) {
                throw new UsernameNotFoundException("10001");
            }

            List<GrantedAuthority> authorities = SecurityUtils.getAuthorities();
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));//如果是中台用户默认都是管理员
            //添加查询组织ID
            String organizationId = null;
            String appId = null;
            List<String> organizationIds = new ArrayList<String>();
            //写入管理员日志
            WebApplicationContext applicationContext = ContextLoader.getCurrentWebApplicationContext();
            AdminLoginAuditLogPersistentEvent adminLoginAuditLogPersistentEvent;
            if (resultHmsAccount.getAdminUserName().toLowerCase().equals("admin")) {//超级管理员
//                organizationIds = sysUserMapper.selectOrganizationIdsByUserName(null);
//                organizationIds.add(0, null);
//                if (organizationIds != null && organizationIds.size() != 0) {
//                    organizationId = organizationIds.get(0);
//                    if (organizationId != null) {
//                        appId = sysUserMapper.selectAppIdByOrganizationId(organizationId);
//                    }
//                }
                adminLoginAuditLogPersistentEvent = new AdminLoginAuditLogPersistentEvent(
                        applicationContext, StatelessRequestHelper.getCurrentRequestRemoteAddr(), resultHmsAccount.getAdminUserName(), null);
            } else {//企业管理员
                organizationIds = sysUserMapper.selectOrganizationIdsByUserName(resultHmsAccount.getAdminUserName());
                if (organizationIds != null && organizationIds.size() != 0) {
                    organizationId = organizationIds.get(0);
                    if (organizationId != null) {
                        appId = sysUserMapper.selectAppIdByOrganizationId(organizationId);
                    }
                }
                adminLoginAuditLogPersistentEvent = new AdminLoginAuditLogPersistentEvent(
                        applicationContext, StatelessRequestHelper.getCurrentRequestRemoteAddr(), resultHmsAccount.getAdminUserName(), organizationId);
            }
            applicationContext.publishEvent(adminLoginAuditLogPersistentEvent);
            webUserDetails = new HmsWebUserDetails(resultHmsAccount.getUserId(), resultHmsAccount.getUserId().toString(),
                    resultHmsAccount.getPasswordEncrypted(), true, true, true, true, authorities, organizationId, appId, null,null,null, resultHmsAccount.getAdminUserName());
        } else if ("WEBTEL".equals(authType)) {
            //校验用户是否已注册
            HmsAccount selectHmsAccount = new HmsAccount();
            if(mobileUsername != null && mobileUsername.startsWith("+86")){
                mobileUsername = mobileUsername.substring(3,mobileUsername.length());
            }
            selectHmsAccount.setPhone(mobileUsername);
            List<HmsAccount> hmsAccountList = this.iHmsAccountService.select(iRequest,selectHmsAccount,1,1);
            if (hmsAccountList.size() == 1 && "N".equals(hmsAccountList.get(0).getHaveRegister())) {
                throw new UsernameNotFoundException("10003");
            }

            HmsStaff selectHmsStaff = new HmsStaff();
            if(mobileUsername != null && mobileUsername.startsWith("+86")){
                mobileUsername = mobileUsername.substring(3,mobileUsername.length());
            }
            selectHmsStaff.setMobile(mobileUsername);
            List<HmsStaff> staffList = iHmsStaffService.select(iRequest,selectHmsStaff,1,1);
//            List<HmsStaff> hmsStaffList = iHmsStaffService.selectAll(iRequest);
//            for (HmsStaff compareHmsStaff : hmsStaffList) {
//                if (compareHmsStaff != null && compareHmsStaff.getMobile() != null) {
//                    if (!compareHmsStaff.getMobile().startsWith("+")) {
//                        if (mobileUsername.equals("+86" + compareHmsStaff.getMobile())) {
//                            hmsStaff = compareHmsStaff;
//                            break;
//                        }
//                    } else {
//                        if (mobileUsername.equals(compareHmsStaff.getMobile())) {
//                            hmsStaff = compareHmsStaff;
//                            break;
//                        }
//                    }
//                }
//            }
            //校验是否匹配租户通讯录
            if (staffList.size() == 0 || staffList.get(0).getOrganizationId() == null) {
                throw new UsernameNotFoundException("10001");
            }
            String phone = staffList.get(0).getMobile();
            HmsAccount ha = new HmsAccount();
            ha.setPhone(phone);
            List<HmsAccount> accountList = this.iHmsAccountService.select(iRequest, ha, 1, 1);
            if (accountList == null || accountList.size() == 0) {
                throw new UsernameNotFoundException("10001");
            }
            HmsAccount account = accountList.get(0);
            if (account.getMasterOrganizationId() == null) {
                throw new UsernameNotFoundException("10001");
            } else if ("Y".equals(account.getStatus()) && (account.getEndActiveDate() == null || account.getEndActiveDate().getTime() >= System.currentTimeMillis())) {
                List authorities = SecurityUtils.getAuthorities();
                String organizationId;
                String appId;
//                List organizationIds;
                authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                organizationId = hmsAccountList.get(0).getMasterOrganizationId();
                appId = this.sysUserMapper.selectAppIdByOrganizationId(organizationId);
                new ArrayList();
                WebApplicationContext userId1 = ContextLoader.getCurrentWebApplicationContext();
                AdminLoginAuditLogPersistentEvent userDetails2;
//                organizationIds = this.iHmsAccountService.selectOrganizationIdsByPhoneAndThirdPartyId(hmsAccountList.get(0).getPhone(),hmsAccountList.get(0).getThirdPartyId());
                userDetails2 = new AdminLoginAuditLogPersistentEvent(userId1, StatelessRequestHelper.getCurrentRequestRemoteAddr(), hmsAccountList.get(0).getPhone(), organizationId);
                userId1.publishEvent(userDetails2);
                webUserDetails = new HmsWebUserDetails(account.getUserId(), account.getUserId().toString(), account.getPasswordEncrypted(), true, true, true, true, authorities, organizationId, appId, account.getPhone(),null,null,null);
            }
        } else {
            throw new UsernameNotFoundException("10004");
        }
        return webUserDetails;
    }
}
