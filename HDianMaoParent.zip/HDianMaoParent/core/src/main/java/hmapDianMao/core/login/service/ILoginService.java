package hmapDianMao.core.login.service;

/**
 * Created by enlline on 9/10/17.
 */
public interface ILoginService {
    public void  handAdminLoginFunction(String userName,String password,String organizationId);
}
