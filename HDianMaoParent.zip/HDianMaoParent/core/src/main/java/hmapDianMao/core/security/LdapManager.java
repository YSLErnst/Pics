package hmapDianMao.core.security;

import org.springframework.ldap.core.LdapTemplate;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;

/**
 * Created by enlline on 5/3/17.
 */
public class LdapManager {
    private List<LdapTemplate> ldapTemplateList;

    public LdapManager(List<LdapTemplate> ldapTemplateList) {
        this.ldapTemplateList = ldapTemplateList;
    }

    public List<LdapTemplate> getLdapTemplateList() {
        return ldapTemplateList;
    }

    public void setLdapTemplateList(List<LdapTemplate> ldapTemplateList) {
        this.ldapTemplateList = ldapTemplateList;
    }

    public LdapTemplate getLdapTemplate(String beanName) {
        WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
        LdapTemplate ldapTemplate = (LdapTemplate)wac.getBean(beanName);
        return ldapTemplate;
    }
}
